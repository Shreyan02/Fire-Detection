Jupyter Notebook Installation Guide:

https://www.geeksforgeeks.org/how-to-install-jupyter-notebook-in-windows/

After opening Jupyter Notebook:
- Go to file destination
- Open ipynb files


Student Details:

Name - Shreyan Misra